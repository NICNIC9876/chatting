<form action="recover.php" method="POST">
<center><span style="color: #000000;">-----Registration Number-----</span><br>
<input type="text" name="username" value="" /><br><br>
<input type="submit" value="Next" />
</form>
<br /><br /><br /><br />
<p> Powered By Muhammad Abba Gana</p>